(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var LocalCollection = Package.minimongo.LocalCollection;
var Minimongo = Package.minimongo.Minimongo;
var ObserveSequence = Package['observe-sequence'].ObserveSequence;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/urigo_angular/packages/urigo_angular.js                  //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['urigo:angular'] = {};

})();

//# sourceMappingURL=urigo_angular.js.map
